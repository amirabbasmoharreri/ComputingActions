package ir.mirrajabi.persiancalendar.core.exceptions;

/**
 * @author Amir
 */

public class YearOutOfRangeException extends RuntimeException {
    private static final long serialVersionUID = -9154217686200590192L;

    public YearOutOfRangeException() {
        super();
    }

    public YearOutOfRangeException(String arg0) {
        super(arg0);
    }

}
