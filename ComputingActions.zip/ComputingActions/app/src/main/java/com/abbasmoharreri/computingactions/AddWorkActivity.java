package com.abbasmoharreri.computingactions;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.abbasmoharreri.computingactions.database.DataBaseController;
import com.abbasmoharreri.computingactions.model.Work;
import com.abbasmoharreri.computingactions.ui.WorkPresenter;
import com.mohamadamin.persianmaterialdatetimepicker.utils.PersianCalendar;
import com.mohamadamin.persianmaterialdatetimepicker.date.DatePickerDialog;
import com.otaliastudios.autocomplete.Autocomplete;
import com.otaliastudios.autocomplete.AutocompleteCallback;
import com.otaliastudios.autocomplete.AutocompletePresenter;
import com.xw.repo.BubbleSeekBar;

public class AddWorkActivity extends AppCompatActivity implements View.OnClickListener, DatePickerDialog.OnDateSetListener {

    DatePickerDialog datePickerDialog;
    Button addButton;
    EditText dateText, workName;
    PersianCalendar persianCalendar;
    DataBaseController dataBaseController;
    BubbleSeekBar seekBarPoint;
    int year, month, day;
    String dayName;
    Autocomplete workNameAutocomplete;

    //creating AddWorkActivity and initialize components

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_add_work );
        setTitle( R.string.add_work_activity_title );

        //enabling back Button in ActionBar
        getSupportActionBar().setDisplayHomeAsUpEnabled( true );

        addButton = findViewById( R.id.add_button );
        addButton.setOnClickListener( this );
        dateText = findViewById( R.id.datePicker_text );
        dateText.setOnClickListener( this );
        workName = findViewById( R.id.workName_text );
        seekBarPoint = findViewById( R.id.seekBar_point );
        persianCalendar = new PersianCalendar();
        setupWorkNameAutoComplete();
    }

    //when clicking on back Button on ActionBar calling this method

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // API 5+ solution
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected( item );
        }
    }


    @Override
    protected void onPause() {
        super.onPause();
        overridePendingTransition( android.R.anim.slide_in_left, android.R.anim.slide_out_right );
    }


    @Override
    protected void onResume() {
        super.onResume();

        workName.addTextChangedListener( new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                workNameAutocomplete.showPopup( s );

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        } );

    }


    //this method for clicking on components

    @Override
    public void onClick(View v) {


        switch (v.getId()) {
            case R.id.datePicker_text:
                datePickerDialog = DatePickerDialog.newInstance( this
                        , persianCalendar.getPersianYear()
                        , persianCalendar.getPersianMonth()
                        , persianCalendar.getPersianDay() );
                datePickerDialog.show( getFragmentManager(), "" );
                break;
            case R.id.add_button:
                Work work = new Work( workName.getText().toString()
                        , this.day
                        , this.month
                        , this.year
                        , seekBarPoint.getProgress() ).setDayName( this.dayName );
                Log.e( "abbasMsg", "Add Button" );
                Toast.makeText( this, "Saved", Toast.LENGTH_SHORT ).show();
                try {
                    dataBaseController = new DataBaseController( getApplicationContext() );
                    dataBaseController.addWorkList( work );
                    dataBaseController.close();
                } catch (Exception e) {
                    Log.e( "Error", e.toString() );
                    e.printStackTrace();
                }

                break;

        }
    }


    @Override
    protected void onStart() {
        super.onStart();
    }

    //setting Data of Date by PersianCalender

    @Override
    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
        String date = year + "/" + (monthOfYear + 1) + "/" + dayOfMonth;
        dateText.setText( date );
        this.year = year;
        this.month = monthOfYear + 1;
        this.day = dayOfMonth;
        this.dayName = persianCalendar.getPersianWeekDayName();

    }


    //setting ability of Auto Complete for WorkName EditText

    private void setupWorkNameAutoComplete() {

        float elevation = 6f;
        Drawable backgroundDrawable = new ColorDrawable( Color.WHITE );
        AutocompletePresenter<Work> presenter = new WorkPresenter( this );
        AutocompleteCallback<Work> callback = new AutocompleteCallback<Work>() {
            @Override
            public boolean onPopupItemClicked(Editable editable, Work item) {
                editable.clear();
                editable.append( item.getName() );
                return true;
            }

            public void onPopupVisibilityChanged(boolean shown) {
            }
        };

        workNameAutocomplete = Autocomplete.<Work>on( workName )
                .with( elevation )
                .with( backgroundDrawable )
                .with( presenter )
                .with( callback )
                .build();

    }

}
