package com.abbasmoharreri.computingactions;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.abbasmoharreri.computingactions.finalVariables.ReportType;
import com.abbasmoharreri.computingactions.model.Work;
import com.abbasmoharreri.computingactions.ui.TypePresenter;
import com.abbasmoharreri.computingactions.ui.WorkPresenter;
import com.github.florent37.materialtextfield.MaterialTextField;
import com.mohamadamin.persianmaterialdatetimepicker.utils.PersianCalendar;
import com.mohamadamin.persianmaterialdatetimepicker.date.DatePickerDialog;
import com.otaliastudios.autocomplete.Autocomplete;
import com.otaliastudios.autocomplete.AutocompleteCallback;
import com.otaliastudios.autocomplete.AutocompletePresenter;


public class ShowActivity extends AppCompatActivity implements View.OnClickListener, DatePickerDialog.OnDateSetListener, TextWatcher {

    Button showButton;
    MaterialTextField materialTextField;
    Autocomplete typeAutoComplete;
    Autocomplete workNameAutocomplete;
    EditText type, workName, dateStart, dateEnd;
    int startDay, startMonth, startYear, endDay, endMonth, endYear;
    String startName, endName;
    PersianCalendar persianCalendar;
    DatePickerDialog datePickerDialog;

    //creating ShowActivity and initialize components

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_show );
        setTitle( R.string.show_activity_title );

        //enabling backButton in ActionBar

        getSupportActionBar().setDisplayHomeAsUpEnabled( true );

        showButton = new Button( getApplicationContext() );
        showButton = findViewById( R.id.showActivity_showButton );
        showButton.setOnClickListener( this );

        materialTextField = new MaterialTextField( getApplicationContext() );
        materialTextField = findViewById( R.id.specific_work );
        materialTextField.setVisibility( View.INVISIBLE );

        type = findViewById( R.id.show_type_editText );
        type.setOnClickListener( this );
        type.setInputType( InputType.TYPE_NULL );
        type.addTextChangedListener( this );

        workName = findViewById( R.id.specific_work_editText );
        workName.addTextChangedListener( this );

        dateStart = findViewById( R.id.start_calender_editText );
        dateStart.setOnClickListener( this );

        dateEnd = findViewById( R.id.end_calender_editText );
        dateEnd.setOnClickListener( this );

        persianCalendar = new PersianCalendar();
        setupTypeAutoComplete();
        setupWorkNameAutoComplete();
    }

    //when clicking on backButton in ActionBar calling this method

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // API 5+ solution
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected( item );
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        overridePendingTransition( android.R.anim.slide_in_left, android.R.anim.slide_out_right );
    }


    //this method for clicking on components

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.showActivity_showButton:
                try {
                    chooseTypeShow();
                    Toast.makeText( getApplicationContext(), "Add Button", Toast.LENGTH_SHORT ).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case R.id.show_type_editText:
                typeAutoComplete.showPopup( "" );

                break;
            case R.id.start_calender_editText:
                datePickerDialog = DatePickerDialog.newInstance( this
                        , persianCalendar.getPersianYear()
                        , persianCalendar.getPersianMonth()
                        , persianCalendar.getPersianDay() );
                datePickerDialog.show( getFragmentManager(), "" );
                break;
            case R.id.end_calender_editText:
                datePickerDialog = DatePickerDialog.newInstance( this
                        , persianCalendar.getPersianYear()
                        , persianCalendar.getPersianMonth()
                        , persianCalendar.getPersianDay() );
                datePickerDialog.show( getFragmentManager(), "" );
                break;
        }
    }

    //choosing type of show for showing chart and sending data to ShowChartActivity for show

    private void chooseTypeShow() {
        String[] name = getResources().getStringArray( R.array.ShowReports );

        if (type.getText().toString().equals( name[0] )) {
            Intent intent = new Intent( ShowActivity.this, ShowChartsActivity.class );
            intent.putExtra( "startDay", startDay );
            intent.putExtra( "startMonth", startMonth );
            intent.putExtra( "startYear", startYear );
            intent.putExtra( "startName", startName );
            intent.putExtra( "endDay", endDay );
            intent.putExtra( "endMonth", endMonth );
            intent.putExtra( "endYear", endYear );
            intent.putExtra( "endName", endName );
            intent.putExtra( "type", ReportType.FREQUENCY_OF_WORK_REPORT );
            intent.putExtra( "nameX", getResources().getString( R.string.axe_x_work ) );
            intent.putExtra( "nameY", getResources().getString( R.string.axe_y_number ) );
            startActivity( intent );

        } else if (type.getText().toString().equals( name[1] )) {

            Intent intent = new Intent( ShowActivity.this, ShowChartsActivity.class );
            intent.putExtra( "startDay", startDay );
            intent.putExtra( "startMonth", startMonth );
            intent.putExtra( "startYear", startYear );
            intent.putExtra( "startName", startName );
            intent.putExtra( "endDay", endDay );
            intent.putExtra( "endMonth", endMonth );
            intent.putExtra( "endYear", endYear );
            intent.putExtra( "endName", endName );
            intent.putExtra( "type", ReportType.POINT_REPORT );
            intent.putExtra( "nameX", getResources().getString( R.string.axe_x_work ) );
            intent.putExtra( "nameY", getResources().getString( R.string.axe_y_point ) );
            startActivity( intent );

        } else if (type.getText().toString().equals( name[2] )) {

            Intent intent = new Intent( ShowActivity.this, ShowChartsActivity.class );
            intent.putExtra( "startDay", startDay );
            intent.putExtra( "startMonth", startMonth );
            intent.putExtra( "startYear", startYear );
            intent.putExtra( "startName", startName );
            intent.putExtra( "endDay", endDay );
            intent.putExtra( "endMonth", endMonth );
            intent.putExtra( "endYear", endYear );
            intent.putExtra( "endName", endName );
            intent.putExtra( "type", ReportType.CONDITION_REPORT );
            intent.putExtra( "nameX", getResources().getString( R.string.axe_x_condition ) );
            intent.putExtra( "nameY", getResources().getString( R.string.axe_y_percent ) );
            startActivity( intent );

        } else if (type.getText().toString().equals( name[3] )) {

            Intent intent = new Intent( ShowActivity.this, ShowChartsActivity.class );
            intent.putExtra( "startDay", startDay );
            intent.putExtra( "startMonth", startMonth );
            intent.putExtra( "startYear", startYear );
            intent.putExtra( "startName", startName );
            intent.putExtra( "endDay", endDay );
            intent.putExtra( "endMonth", endMonth );
            intent.putExtra( "endYear", endYear );
            intent.putExtra( "endName", endName );
            intent.putExtra( "workName", workName.getText().toString() );
            intent.putExtra( "type", ReportType.SPECIAL_WORK_REPORT );
            intent.putExtra( "nameX", getResources().getString( R.string.axe_x_date ) );
            intent.putExtra( "nameY", getResources().getString( R.string.axe_y_point ) );
            startActivity( intent );

        } else if (type.getText().toString().equals( name[4] )) {

            Intent intent = new Intent( ShowActivity.this, ShowChartsActivity.class );
            intent.putExtra( "startDay", startDay );
            intent.putExtra( "startMonth", startMonth );
            intent.putExtra( "startYear", startYear );
            intent.putExtra( "startName", startName );
            intent.putExtra( "endDay", endDay );
            intent.putExtra( "endMonth", endMonth );
            intent.putExtra( "endYear", endYear );
            intent.putExtra( "endName", endName );
            intent.putExtra( "type", ReportType.ASC_AND_DESC_REPORT );
            intent.putExtra( "nameX", getResources().getString( R.string.axe_x_work ) );
            intent.putExtra( "nameY", getResources().getString( R.string.axe_y_point ) );
            startActivity( intent );
        }


    }

    //setting ability of Auto complete for Type of Report EditText

    private void setupTypeAutoComplete() {

        float elevation = 6f;
        Drawable backgroundDrawable = new ColorDrawable( Color.WHITE );
        AutocompletePresenter<String> presenter = new TypePresenter( this );
        AutocompleteCallback<String> callback = new AutocompleteCallback<String>() {
            @Override
            public boolean onPopupItemClicked(Editable editable, String item) {
                editable.clear();
                editable.append( item );
                return true;
            }

            @Override
            public void onPopupVisibilityChanged(boolean shown) {

            }
        };

        typeAutoComplete = Autocomplete.<String>on( type )
                .with( elevation )
                .with( backgroundDrawable )
                .with( presenter )
                .with( callback )
                .build();

    }

    //setting ability of Auto complete for WorkName EditText

    private void setupWorkNameAutoComplete() {

        float elevation = 6f;
        Drawable backgroundDrawable = new ColorDrawable( Color.WHITE );
        AutocompletePresenter<Work> presenter = new WorkPresenter( this );
        AutocompleteCallback<Work> callback = new AutocompleteCallback<Work>() {
            @Override
            public boolean onPopupItemClicked(Editable editable, Work item) {
                editable.clear();
                editable.append( item.getName() );
                return true;
            }

            public void onPopupVisibilityChanged(boolean shown) {
            }
        };

        workNameAutocomplete = Autocomplete.<Work>on( workName )
                .with( elevation )
                .with( backgroundDrawable )
                .with( presenter )
                .with( callback )
                .build();

    }

    //when string of EditText changing calling this methods

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        if (type.hasFocus()) {
            String[] name = getResources().getStringArray( R.array.ShowReports );
            if (s.toString().equals( name[3] )) {
                materialTextField.setVisibility( View.VISIBLE );
            } else {
                materialTextField.setVisibility( View.INVISIBLE );
            }

        } else if (workName.hasFocus()) {
            workNameAutocomplete.showPopup( s );
        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }

    //setting data of Date by PersianCalender

    @Override
    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
        String date = year + "/" + (monthOfYear + 1) + "/" + dayOfMonth;
        if (dateStart.hasFocus()) {
            dateStart.setText( date );
            this.startYear = year;
            this.startMonth = monthOfYear + 1;
            this.startDay = dayOfMonth;
            this.startName = persianCalendar.getPersianWeekDayName();
        } else if (dateEnd.hasFocus()) {
            dateEnd.setText( date );
            this.endYear = year;
            this.endMonth = monthOfYear + 1;
            this.endDay = dayOfMonth;
            this.endName = persianCalendar.getPersianWeekDayName();
        }
    }
}
