package com.abbasmoharreri.computingactions.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.view.animation.Animation;

import com.abbasmoharreri.computingactions.R;
import com.abbasmoharreri.computingactions.model.Container;

import java.util.ArrayList;
import java.util.List;

import lecho.lib.hellocharts.animation.ChartAnimationListener;
import lecho.lib.hellocharts.animation.PieChartRotationAnimator;
import lecho.lib.hellocharts.animation.PieChartRotationAnimatorV14;
import lecho.lib.hellocharts.listener.PieChartOnValueSelectListener;
import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.util.ChartUtils;
import lecho.lib.hellocharts.view.Chart;
import lecho.lib.hellocharts.view.PieChartView;

public class PieChart {

    private PieChartView chart;
    private PieChartData data;

    private boolean hasLabels = true;
    private boolean hasLabelsOutside = false;
    private boolean hasCenterCircle = true;
    private boolean hasCenterText1 = true;
    private boolean hasCenterText2 = true;
    private boolean isExploded = false;
    private boolean hasLabelForSelected = true;

    private int numValues;
    private List<Container> value;
    private Context context;

    public PieChart(Context context, PieChartView chart, int numValues, List<Container> value) {
        this.context = context;
        this.chart = chart;
        this.numValues = numValues;
        this.value = value;
        chart.setOnValueTouchListener( new ValueTouchListener() );
        generateData();
    }


    //resetting all values

    private void reset() {
        chart.setCircleFillRatio( 1.0f );
        hasLabels = true;
        hasLabelsOutside = false;
        hasCenterCircle = false;
        hasCenterText1 = true;
        hasCenterText2 = true;
        isExploded = false;
        hasLabelForSelected = true;
    }


    //generate data for show in chart

    private void generateData() {

        //setting values for showing

        List<SliceValue> values = new ArrayList<>();
        for (int i = 0; i < numValues; ++i) {
            SliceValue sliceValue = new SliceValue( value.get( i ).getPercent(), ChartUtils.nextColor() ).setLabel( value.get( i ).getName() );
            values.add( sliceValue );
        }

        //setting data in chart and abilities

        data = new PieChartData( values );
        data.setHasLabels( hasLabels );
        data.setHasLabelsOnlyForSelected( hasLabelForSelected );
        data.setHasLabelsOutside( hasLabelsOutside );
        data.setHasCenterCircle( hasCenterCircle );

        if (isExploded) {
            data.setSlicesSpacing( 24 );
        }


        //setting text for chart

        if (hasCenterText1) {
            data.setCenterText1( value.get( 0 ).getDescription() );


            // Get roboto-italic font.
           /* Typeface tf = Typeface.createFromAsset( context.getAssets(), "chartfont.ttf" );
            data.setCenterText1Typeface( tf );

            // Get font size from dimens.xml and convert it to sp(library uses sp values).
            data.setCenterText1FontSize( ChartUtils.px2sp( context.getResources().getDisplayMetrics().scaledDensity,
                    R.dimen.pie_chart_text1_size ) );*/
        }

        //setting text for chart

        if (hasCenterText2) {
            data.setCenterText2( value.get( 0 ).getDescription2() );

            /*Typeface tf = Typeface.createFromAsset( context.getAssets(), "chartfont.ttf" );
            data.setCenterText2Typeface( tf );

            data.setCenterText2FontSize( ChartUtils.px2sp( context.getResources().getDisplayMetrics().scaledDensity,
                    R.dimen.pie_chart_text2_size ) );*/
        }
        chart.setPieChartData( data );
        prepareDataAnimation();
    }


    private void explodeChart() {
        isExploded = !isExploded;
        generateData();

    }

    //showing labels of chart outside or inside

    private void toggleLabelsOutside() {
        // has labels have to be true:P
        hasLabelsOutside = !hasLabelsOutside;
        if (hasLabelsOutside) {
            hasLabels = true;
            hasLabelForSelected = false;
            chart.setValueSelectionEnabled( hasLabelForSelected );
        }

        if (hasLabelsOutside) {
            chart.setCircleFillRatio( 0.7f );
        } else {
            chart.setCircleFillRatio( 1.0f );
        }

        generateData();

    }

    //showing labels or hiding

    private void toggleLabels() {
        hasLabels = !hasLabels;

        if (hasLabels) {
            hasLabelForSelected = false;
            chart.setValueSelectionEnabled( hasLabelForSelected );

            if (hasLabelsOutside) {
                chart.setCircleFillRatio( 0.7f );
            } else {
                chart.setCircleFillRatio( 1.0f );
            }
        }

        generateData();
    }


    private void toggleLabelForSelected() {
        hasLabelForSelected = !hasLabelForSelected;

        chart.setValueSelectionEnabled( hasLabelForSelected );

        if (hasLabelForSelected) {
            hasLabels = false;
            hasLabelsOutside = false;

            if (hasLabelsOutside) {
                chart.setCircleFillRatio( 0.7f );
            } else {
                chart.setCircleFillRatio( 1.0f );
            }
        }

        generateData();
    }

    //setting animation for chart

    private void prepareDataAnimation() {
        PieChartRotationAnimatorV14 pieChartRotationAnimatorV14 = new PieChartRotationAnimatorV14( chart, 2000 );
        pieChartRotationAnimatorV14.startAnimation( 0, 6 );

    }


    //when selecting  slice of chart , calling this class

    private class ValueTouchListener implements PieChartOnValueSelectListener {

        @Override
        public void onValueSelected(int arcIndex, SliceValue value) {


        }

        @Override
        public void onValueDeselected() {
            // TODO Auto-generated method stub

        }

    }
}
