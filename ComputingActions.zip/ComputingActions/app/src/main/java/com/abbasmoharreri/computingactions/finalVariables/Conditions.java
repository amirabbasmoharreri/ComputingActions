package com.abbasmoharreri.computingactions.finalVariables;

import com.abbasmoharreri.computingactions.R;

public final class Conditions {


    //this values for using method and DataBase

    public static final String Good = "Good";
    public static final String Medium = "Medium";
    public static final String Bad = "Bad";

    //this method for set name of conditions for showing

    public static String getGood() {
        return String.valueOf( R.string.Good );
    }

    public static String getMedium() {
        return String.valueOf( R.string.Medium );
    }

    public static String getBad() {
        return String.valueOf( R.string.Bad );
    }

}
