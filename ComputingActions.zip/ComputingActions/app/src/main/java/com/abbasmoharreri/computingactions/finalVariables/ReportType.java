package com.abbasmoharreri.computingactions.finalVariables;

public final class ReportType {


    //this values for choosing type of Reports

    public final static int POINT_REPORT = 1;
    public final static int ASC_AND_DESC_REPORT = 2;
    public final static int CONDITION_REPORT = 3;
    public final static int FREQUENCY_OF_WORK_REPORT = 4;
    public final static int SPECIAL_WORK_REPORT = 5;
}
